extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

func _draw() -> void:
	# Define the rectangle
	var rect = Rect2(300, 300, 500, 50)
	# Draw the rectangle, defining the color
	draw_rect(rect, Color.BLUE)
	
	# Draw a Filled Circle
	draw_circle(Vector2(300, 300), 10, Color.RED)
	
	# Draw a circle outline (the last parameter is the width of the line)
	draw_circle(Vector2(120, 100), 30, Color.PURPLE, false, 4.0)
	
	# Draw a line. The two Vectors are the end points of the straight line
	draw_line(Vector2(100, 200), Vector2(200, 200), Color.AQUA)
	
	# Draw a thicker line
	draw_line(Vector2(550, 0), Vector2(550, 200), Color.YELLOW, 10)
	
	# Draw an arc. The two "angle" parameters (0 and PI) indicate 
	# which part of the circle to draw. Numbers are between 0 and 2 * PI.
	draw_arc(Vector2(400, 100), 30, 0, PI, 40, Color.PALE_VIOLET_RED)
